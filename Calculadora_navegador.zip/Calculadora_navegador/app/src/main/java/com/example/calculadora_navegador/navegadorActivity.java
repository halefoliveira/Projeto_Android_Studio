package com.example.calculadora_navegador;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;


public class navegadorActivity extends AppCompatActivity {

    Button navegarUrl;
    EditText urlText;
    WebView webp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.navegador);

        navegarUrl = (Button) findViewById(R.id.navegadorBotao);
        urlText = (EditText) findViewById(R.id.url);
        webp = (WebView) findViewById(R.id.web);

        webp.setWebViewClient(new WebViewClient());

        navegarUrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                webp.loadUrl(urlText.getText().toString());
            }
        });

    }
}
