package com.example.calculadora_navegador;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class calculadoraActivity extends AppCompatActivity {


    EditText valor1;
    EditText valor2;
    Button soma;
    Button subtracao;
    Button multiplicacao;
    Button divisao;
    Button porcentagem;
    EditText resultado;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculadora);

        valor1 = (EditText) findViewById(R.id.valor1);
        valor2 = (EditText) findViewById(R.id.valor2);
        soma = (Button) findViewById(R.id.soma);
        subtracao = (Button) findViewById(R.id.subtracao);
        multiplicacao = (Button) findViewById(R.id.multiplicacao);
        divisao = (Button) findViewById(R.id.divisao);
        porcentagem = (Button) findViewById(R.id.porcentagem);
        resultado = (EditText) findViewById(R.id.resultadoConta);

        soma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble(valor1.getText().toString());
                v2 = Double.parseDouble(valor1.getText().toString());
                res = (v1 + v2);
                resultado.setText(res.toString());
            }
        });


        subtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble(valor1.getText().toString());
                v2 = Double.parseDouble(valor1.getText().toString());
                res = v1 - v2;
                resultado.setText(res.toString());
            }
        });

        multiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble(valor1.getText().toString());
                v2 = Double.parseDouble(valor1.getText().toString());
                res = v1 * v2;
                resultado.setText(res.toString());
            }
        });

        divisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble(valor1.getText().toString());
                v2 = Double.parseDouble(valor1.getText().toString());
                res = v1 / v2;
                resultado.setText(res.toString());
            }
        });

        porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble(valor1.getText().toString());
                v2 = Double.parseDouble(valor1.getText().toString());
                res = v1 * v2/100;
                resultado.setText(res.toString());
            }
        });

    }
}