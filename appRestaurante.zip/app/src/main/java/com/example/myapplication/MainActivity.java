package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    EditText c1;
    EditText c2;
    EditText c3;
    EditText r1;
    EditText r2;
    EditText r3;
    Button  button1;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c1 = (EditText) findViewById(R.id.consumo);
        c2 = (EditText) findViewById(R.id.couvert);
        c3 = (EditText) findViewById(R.id.dividirConta);
        r1 = (EditText) findViewById(R.id.total);
        r2 = (EditText) findViewById(R.id.taxaServico);
        r3 = (EditText) findViewById(R.id.valorPessoa);
        button1 =(Button) findViewById(R.id.calcular);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Double valor1;
                Double valor2;
                Double valor3;
                Double resultado1;
                Double resultado2;
                Double resultado3;

                valor1 = Double.parseDouble(c1.getText().toString());
                valor2 = Double.parseDouble(c2.getText().toString());
                valor3 = Double.parseDouble(c3.getText().toString());
                resultado1 = (valor1 + valor2);
                resultado2 = (valor1 + valor2) *10/100;
                resultado3 = (resultado1 + resultado2) / valor3;
                r1.setText(resultado1.toString());
                r2.setText(resultado2.toString());
                r3.setText(resultado3.toString());
            }
        });
    }
}
